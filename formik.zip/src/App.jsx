import CheckBox from "./components/Checkbox";

const App = () => {
  return <CheckBox />;
};

export default App;
