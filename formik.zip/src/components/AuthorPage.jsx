const AuthorPage = () => {
  return <div>AuthorPage</div>;
};

export default AuthorPage;
