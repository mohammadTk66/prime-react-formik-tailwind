const UnauthorizedPage = () => {
  return <div>UnauthorizedPage</div>;
};

export default UnauthorizedPage;
