const GuestPage = () => {
  return <div>GuestPage</div>;
};

export default GuestPage;
