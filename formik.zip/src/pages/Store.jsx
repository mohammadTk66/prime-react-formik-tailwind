const Store = () => {
  return <div>Store</div>;
};

export default Store;
